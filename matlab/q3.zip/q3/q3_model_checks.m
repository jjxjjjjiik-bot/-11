function checks = q3_model_checks(data, profiles, plans, ranking, sensitivitySummary)
% Q3_MODEL_CHECKS  输出模型自检结果。

names = strings(0, 1);
status = strings(0, 1);
details = strings(0, 1);

[names, status, details] = add_check(names, status, details, ...
    "来源清单已读取", height(data.manifest) >= 8, ...
    sprintf("source_count=%d", height(data.manifest)));

[names, status, details] = add_check(names, status, details, ...
    "参数表已读取", height(data.parameters) >= 30, ...
    sprintf("parameter_count=%d", height(data.parameters)));

[names, status, details] = add_check(names, status, details, ...
    "画像数量为 5", height(profiles) == 5, ...
    sprintf("profile_count=%d", height(profiles)));

[names, status, details] = add_check(names, status, details, ...
    "候选方案数量为 15", height(plans) == 15, ...
    sprintf("plan_count=%d", height(plans)));

safeOk = all(plans.is_safe);
[names, status, details] = add_check(names, status, details, ...
    "全部候选方案通过安全硬约束", safeOk, ...
    sprintf("safe_count=%d,total=%d", sum(plans.is_safe), height(plans)));

safeScores = plans.topsis_score(plans.is_safe);
scoreOk = ~isempty(safeScores) && all(safeScores >= 0 & safeScores <= 1);
if isempty(safeScores)
    scoreDetails = "no_safe_scores";
else
    scoreDetails = sprintf("min=%.4f,max=%.4f", min(safeScores), max(safeScores));
end
[names, status, details] = add_check(names, status, details, ...
    "TOPSIS 得分在 0-1 内", scoreOk, ...
    scoreDetails);

coverageCols = {'cover_activity','cover_energy','cover_monitoring', ...
    'cover_unhealthy_food','cover_fruit_veg'};
coverageOk = all(all(plans{:, coverageCols} >= 0 & plans{:, coverageCols} <= 1));
[names, status, details] = add_check(names, status, details, ...
    "失败因素覆盖度在 0-1 内", coverageOk, "five coverage columns checked");

rankOk = true;
for i = 1:height(profiles)
    rows = ranking.profile_id == i;
    rankOk = rankOk && sum(rows) == 3 && isequal(sort(ranking.rank(rows))', [1, 2, 3]);
end
[names, status, details] = add_check(names, status, details, ...
    "每类画像均有 1、2、3 名", rankOk, ...
    sprintf("ranking_rows=%d", height(ranking)));

scenarioOk = all(sensitivitySummary.scenario_count == 10);
[names, status, details] = add_check(names, status, details, ...
    "权重敏感性每类完成 10 个扰动情景", scenarioOk, ...
    sprintf("scenario_count=%s", mat2str(sensitivitySummary.scenario_count')));

checks = table(names, status, details, 'VariableNames', {'check_name','status','details'});
end

function [names, status, details] = add_check(names, status, details, checkName, passed, detail)
names(end+1, 1) = checkName;
if passed
    status(end+1, 1) = "PASS";
else
    status(end+1, 1) = "FAIL";
end
details(end+1, 1) = detail;
end

function value = get_param(paramMap, parameterId)
if ~isKey(paramMap, parameterId)
    error('缺少参数：%s。请检查 q3_parameter_table.csv。', parameterId);
end
value = paramMap(parameterId);
end
