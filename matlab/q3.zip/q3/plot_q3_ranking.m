function plot_q3_ranking(ranking)
% PLOT_Q3_RANKING  生成各类人群最优方案得分柱状图窗口。

fontName = q3_choose_font();
bestRows = false(height(ranking), 1);
profileIds = unique(ranking.profile_id, 'stable');
for i = 1:numel(profileIds)
    idx = find(ranking.profile_id == profileIds(i));
    [~, localBest] = max(ranking.topsis_score(idx));
    bestRows(idx(localBest)) = true;
end
best = ranking(bestRows, :);

fig = figure('Name', '问题三-各类人群最优方案得分', ...
    'NumberTitle', 'off', 'Color', 'w', 'Position', [120 90 1180 720]);
ax = axes('Parent', fig);
hold(ax, 'on');

barColors = [0.18 0.45 0.70; 0.25 0.63 0.39; 0.78 0.45 0.18; 0.58 0.43 0.72; 0.70 0.55 0.24];
b = bar(ax, best.topsis_score, 0.62, 'FaceColor', 'flat');
for i = 1:height(best)
    b.CData(i, :) = barColors(i, :);
end

topLimit = min(1.08, max(best.topsis_score) + 0.20);
ylim(ax, [0, topLimit]);
xlim(ax, [0.4, height(best) + 0.6]);
grid(ax, 'on');
ax.GridAlpha = 0.18;
ax.LineWidth = 1.0;
ax.FontName = fontName;
ax.FontSize = 13;
ax.XTick = 1:height(best);
ax.XTickLabel = best.profile_name;
ax.XTickLabelRotation = 18;
ylabel(ax, 'TOPSIS 综合得分（越高越优）', 'FontName', fontName, 'FontSize', 14);
xlabel(ax, '典型工作生活方式画像', 'FontName', fontName, 'FontSize', 14);
title(ax, '问题三-各类人群最优方案得分', 'FontName', fontName, ...
    'FontSize', 18, 'FontWeight', 'bold');

for i = 1:height(best)
    labelText = sprintf('推荐：%s\\n得分 %.3f', best.plan_type(i), best.topsis_score(i));
    text(ax, i, best.topsis_score(i) + 0.025, labelText, ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
        'FontName', fontName, 'FontSize', 12, 'FontWeight', 'bold');
end

set(ax, 'LooseInset', max(get(ax, 'TightInset'), [0.05 0.05 0.05 0.05]));
hold(ax, 'off');
end

function fontName = q3_choose_font()
preferred = {'Microsoft YaHei', 'SimHei', 'SimSun'};
available = listfonts;
fontName = get(groot, 'defaultAxesFontName');
for i = 1:numel(preferred)
    if any(strcmpi(available, preferred{i}))
        fontName = preferred{i};
        return;
    end
end
end
