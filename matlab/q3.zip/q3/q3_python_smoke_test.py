import csv
import math
from pathlib import Path


ROOT = Path(r"D:\数学建模")
SOURCE_DIR = ROOT / "数据来源" / "q3"
OUTPUT_DIR = ROOT / "matlab" / "q3" / "output"


def read_params():
    path = SOURCE_DIR / "q3_parameter_table.csv"
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    values = {}
    for row in rows:
        try:
            values[row["parameter_id"]] = float(row["value"])
        except ValueError:
            pass
    return rows, values


def build_profiles():
    return [
        {"profile_id": 1, "profile_name": "久坐办公型", "sedentary_risk": 95, "sleep_risk": 50, "diet_risk": 75, "stress_risk": 50, "time_constraint": 75, "monitoring_gap": 75},
        {"profile_id": 2, "profile_name": "夜班熬夜型", "sedentary_risk": 75, "sleep_risk": 95, "diet_risk": 75, "stress_risk": 75, "time_constraint": 95, "monitoring_gap": 75},
        {"profile_id": 3, "profile_name": "高压应酬型", "sedentary_risk": 75, "sleep_risk": 75, "diet_risk": 95, "stress_risk": 95, "time_constraint": 75, "monitoring_gap": 75},
        {"profile_id": 4, "profile_name": "时间受限型", "sedentary_risk": 75, "sleep_risk": 75, "diet_risk": 50, "stress_risk": 75, "time_constraint": 95, "monitoring_gap": 75},
        {"profile_id": 5, "profile_name": "饮食失衡型", "sedentary_risk": 50, "sleep_risk": 50, "diet_risk": 95, "stress_risk": 50, "time_constraint": 50, "monitoring_gap": 75},
    ]


def plan_spec(profile_name, plan_type):
    if plan_type == "饮食优先型":
        spec = dict(energy_deficit_kcal_day=750, aerobic_min_week=150, strength_days_week=2,
                    monitoring_days_week=5, sleep_action_score=65, diet_structure_score=92,
                    cover_activity=0.5, cover_energy=1.0, cover_monitoring=0.5,
                    cover_unhealthy_food=1.0, cover_fruit_veg=1.0,
                    time_burden_min_day=46,
                    plan_summary="控能量、控油糖快餐、提高蔬菜全谷物，运动保持指南下限。")
    elif plan_type == "运动优先型":
        spec = dict(energy_deficit_kcal_day=550, aerobic_min_week=300, strength_days_week=3,
                    monitoring_days_week=4, sleep_action_score=60, diet_structure_score=70,
                    cover_activity=1.0, cover_energy=0.5, cover_monitoring=0.5,
                    cover_unhealthy_food=0.5, cover_fruit_veg=0.5,
                    time_burden_min_day=66,
                    plan_summary="提高有氧和抗阻训练，饮食控制保持保守能量缺口。")
    else:
        spec = dict(energy_deficit_kcal_day=650, aerobic_min_week=210, strength_days_week=2,
                    monitoring_days_week=6, sleep_action_score=78, diet_structure_score=84,
                    cover_activity=1.0, cover_energy=1.0, cover_monitoring=1.0,
                    cover_unhealthy_food=1.0, cover_fruit_veg=1.0,
                    time_burden_min_day=55,
                    plan_summary="饮食、运动、监测和睡眠同步推进，追求稳态执行。")
    spec["plan_type"] = plan_type
    spec["sleep_hours_target"] = 7
    spec["feasibility_penalty"] = 0
    spec["feasibility_bonus"] = 0
    if profile_name == "久坐办公型":
        spec["time_burden_min_day"] += 2
        spec["plan_summary"] += "；每坐 60 分钟起身活动 3-5 分钟，每周安排 5 次午间步行和 2 次下班有氧。"
    elif profile_name == "夜班熬夜型":
        spec["sleep_action_score"] = min(100, spec["sleep_action_score"] + 15)
        spec["feasibility_penalty"] = 9
        spec["time_burden_min_day"] += 4
        spec["cover_monitoring"] = 1.0
        spec["plan_summary"] += "；夜班日采用 3+1 餐次，按班次固定不少于 7 小时睡眠窗口，备低能量加餐并记录夜间进食。"
    elif profile_name == "高压应酬型":
        spec["feasibility_penalty"] = 7
        spec["cover_monitoring"] = 1.0
        spec["plan_summary"] += "；应酬前定量加餐，酒桌优先蔬菜和优质蛋白；应酬次日不极端节食，补做 30 分钟快走并记录饮酒外食。"
    elif profile_name == "时间受限型":
        spec["monitoring_days_week"] = min(7, spec["monitoring_days_week"] + 1)
        spec["time_burden_min_day"] -= 8
        spec["feasibility_bonus"] = 4
        spec["cover_monitoring"] = 1.0
        spec["plan_summary"] += "；每日安排 3 次 10-15 分钟碎片化运动，周末集中备餐，手机记录体重和饮食。"
    elif profile_name == "饮食失衡型":
        spec["diet_structure_score"] = min(100, spec["diet_structure_score"] + 8)
        spec["plan_summary"] += "；替换甜食油炸快餐，保证每日蔬菜 300-500g 和全谷杂豆。"
    return spec


def safety_gate(spec, p):
    return (
        p["P08"] <= spec["energy_deficit_kcal_day"] <= p["P09"] and
        p["P14"] <= spec["aerobic_min_week"] <= p["P15"] and
        p["P16"] <= spec["strength_days_week"] <= p["P17"] and
        spec["sleep_hours_target"] >= p["P20"]
    )


def feasibility_score(spec, profile):
    time_risk = profile["time_constraint"] / 100
    sleep_risk = profile["sleep_risk"] / 100
    stress_risk = profile["stress_risk"] / 100
    burden_penalty = max(0, spec["time_burden_min_day"] - 45) * (0.35 + 0.45 * time_risk)
    sleep_fit = spec["sleep_action_score"] * sleep_risk * 0.08
    monitoring_fit = spec["monitoring_days_week"] * 1.2
    score = (78 - burden_penalty - 7 * stress_risk + sleep_fit + monitoring_fit +
             profile_plan_fit(spec["plan_type"], profile) -
             single_focus_penalty(spec["plan_type"], profile))
    score = score - spec["feasibility_penalty"] + spec["feasibility_bonus"]
    return max(0, min(100, score))


def persistence_score(spec, profile):
    monitoring = spec["monitoring_days_week"] / 7 * 100
    score = (48 + 0.20 * monitoring + 0.18 * spec["sleep_action_score"] +
             0.12 * spec["diet_structure_score"] -
             max(0, spec["time_burden_min_day"] - 50) * 0.35 -
             8 * profile["stress_risk"] / 100 -
             0.60 * single_focus_penalty(spec["plan_type"], profile))
    return max(0, min(100, score))


def profile_plan_fit(plan_type, profile):
    if plan_type == "饮食优先型":
        score = 0.16 * profile["diet_risk"] + 0.04 * profile["stress_risk"] - 6
    elif plan_type == "运动优先型":
        score = 0.18 * profile["sedentary_risk"] - 0.12 * profile["time_constraint"] - 2
    else:
        score = (0.09 * profile["sleep_risk"] + 0.08 * profile["stress_risk"] +
                 0.06 * profile["monitoring_gap"] - 3)
    return max(-8, min(14, score))


def single_focus_penalty(plan_type, profile):
    if plan_type == "饮食优先型":
        return max(0, 0.12 * profile["sleep_risk"] + 0.10 * profile["stress_risk"] -
                   0.10 * profile["diet_risk"])
    if plan_type == "运动优先型":
        return 0.08 * profile["diet_risk"] + 0.05 * profile["sleep_risk"]
    return 0


def build_plans(profiles, p):
    plans = []
    period_days = round(p["P05"] * 30)
    target_min_kg = p["P03"] * p["P06"] / 100
    target_max_kg = p["P03"] * p["P07"] / 100
    for profile in profiles:
        for j, plan_type in enumerate(["饮食优先型", "运动优先型", "综合平衡型"], start=1):
            spec = plan_spec(profile["profile_name"], plan_type)
            diet_loss = spec["energy_deficit_kcal_day"] * period_days / p["P27"]
            exercise_loss = (spec["aerobic_min_week"] * 6.0 * 4.345 *
                             p["P05"] / p["P27"])
            raw_loss = 0.35 * diet_loss + 0.45 * exercise_loss
            expected_loss = min(max(raw_loss, target_min_kg * 0.70), target_max_kg)
            coverage = [spec["cover_activity"], spec["cover_energy"], spec["cover_monitoring"],
                        spec["cover_unhealthy_food"], spec["cover_fruit_veg"]]
            plan = {
                "plan_id": f"P{profile['profile_id']}_{j}",
                "profile_id": profile["profile_id"],
                "profile_name": profile["profile_name"],
                "plan_type": plan_type,
                **{k: spec[k] for k in [
                    "energy_deficit_kcal_day", "aerobic_min_week", "strength_days_week",
                    "monitoring_days_week", "sleep_hours_target", "sleep_action_score", "diet_structure_score",
                    "time_burden_min_day", "cover_activity", "cover_energy", "cover_monitoring",
                    "cover_unhealthy_food", "cover_fruit_veg", "plan_summary"]},
                "expected_loss_kg_6m": expected_loss,
                "effect_score": min(100, 100 * expected_loss / target_max_kg),
                "is_safe": safety_gate(spec, p),
                "feasibility_score": feasibility_score(spec, profile),
                "persistence_score": persistence_score(spec, profile),
                "failure_coverage_score": sum(coverage) / len(coverage) * 100,
            }
            plans.append(plan)
    return plans


def topsis(plans, p, weights=None):
    criteria = ["effect_score", "feasibility_score", "persistence_score", "failure_coverage_score", "time_burden_min_day"]
    if weights is None:
        weights = [p["P28"], p["P30"], p["P31"], p["P32"], p["P33"]]
    total = sum(weights)
    weights = [w / total for w in weights]
    types = [1, 1, 1, 1, -1]
    for profile_id in sorted(set(plan["profile_id"] for plan in plans)):
        group = [plan for plan in plans if plan["profile_id"] == profile_id and plan["is_safe"]]
        matrix = [[float(plan[c]) for c in criteria] for plan in group]
        norm = [math.sqrt(sum(row[j] ** 2 for row in matrix)) or 1 for j in range(len(criteria))]
        weighted = [[row[j] / norm[j] * weights[j] for j in range(len(criteria))] for row in matrix]
        best, worst = [], []
        for j, ctype in enumerate(types):
            col = [row[j] for row in weighted]
            best.append(max(col) if ctype == 1 else min(col))
            worst.append(min(col) if ctype == 1 else max(col))
        for plan, row in zip(group, weighted):
            d_best = math.sqrt(sum((row[j] - best[j]) ** 2 for j in range(len(criteria))))
            d_worst = math.sqrt(sum((row[j] - worst[j]) ** 2 for j in range(len(criteria))))
            plan["distance_to_best"] = d_best
            plan["distance_to_worst"] = d_worst
            plan["topsis_score"] = d_worst / (d_best + d_worst)

        group = sorted(group, key=lambda r: -r["topsis_score"])
        for rank, plan in enumerate(group, start=1):
            plan["rank"] = rank
    return plans


def perturb_weight(baseline_weights, target_index, multiplier):
    total = sum(baseline_weights)
    assert total > 0
    base = [weight / total for weight in baseline_weights]
    target_weight = base[target_index] * multiplier
    assert 0 < target_weight < 1
    other_indices = [i for i in range(len(base)) if i != target_index]
    other_base_total = sum(base[i] for i in other_indices)
    adjusted = [0.0] * len(base)
    adjusted[target_index] = target_weight
    for i in other_indices:
        adjusted[i] = base[i] / other_base_total * (1 - target_weight)
    return adjusted


def sensitivity(plans, p):
    base_weights = [p["P28"], p["P30"], p["P31"], p["P32"], p["P33"]]
    criteria = ["effect_score", "feasibility_score", "persistence_score", "failure_coverage_score", "time_burden_min_day"]
    baseline = [dict(plan) for plan in plans]
    topsis(baseline, p, base_weights)
    rows = []
    for profile_id in sorted(set(plan["profile_id"] for plan in plans)):
        base_group = [plan for plan in baseline if plan["profile_id"] == profile_id and plan["rank"] == 1]
        baseline_best = base_group[0]["plan_type"]
        for j, criterion in enumerate(criteria):
            for multiplier in [0.8, 1.2]:
                adjusted = perturb_weight(base_weights, j, multiplier)
                candidate = [dict(plan) for plan in plans]
                topsis(candidate, p, adjusted)
                best = [plan for plan in candidate if plan["profile_id"] == profile_id and plan["rank"] == 1][0]
                rows.append({
                    "profile_id": profile_id,
                    "profile_name": best["profile_name"],
                    "perturbed_criterion": criterion,
                    "weight_multiplier": multiplier,
                    "baseline_best_plan": baseline_best,
                    "perturbed_best_plan": best["plan_type"],
                    "best_plan_unchanged": baseline_best == best["plan_type"],
                })
    return rows


def write_csv(path, rows):
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    parameter_rows, params = read_params()
    profiles = build_profiles()
    plans = build_plans(profiles, params)
    topsis(plans, params)
    sensitivity_rows = sensitivity(plans, params)
    base_weights = [params["P28"], params["P30"], params["P31"], params["P32"], params["P33"]]
    normalized_base = [weight / sum(base_weights) for weight in base_weights]
    for index in range(len(base_weights)):
        for multiplier in [0.8, 1.2]:
            adjusted = perturb_weight(base_weights, index, multiplier)
            assert abs(sum(adjusted) - 1.0) < 1e-12
            assert abs(adjusted[index] - normalized_base[index] * multiplier) < 1e-12
    ranking = sorted(plans, key=lambda r: (r["profile_id"], r["rank"], r["plan_type"]))
    write_csv(OUTPUT_DIR / "q3_python_profile_scores.csv", profiles)
    write_csv(OUTPUT_DIR / "q3_python_plan_scores.csv", plans)
    write_csv(OUTPUT_DIR / "q3_python_plan_ranking.csv", ranking)
    write_csv(OUTPUT_DIR / "q3_python_parameter_table_used.csv", parameter_rows)
    write_csv(OUTPUT_DIR / "q3_python_weight_sensitivity.csv", sensitivity_rows)
    assert all(plan["is_safe"] for plan in plans)
    assert len(sensitivity_rows) == 50
    assert all(sum(row["profile_id"] == pid for row in sensitivity_rows) == 10
               for pid in range(1, 6))
    print(f"Python smoke test OK: profiles={len(profiles)}, plans={len(plans)}")
    for row in ranking:
        if row["rank"] == 1:
            print(f"{row['profile_name']}: {row['plan_type']} score={row['topsis_score']:.4f}")


if __name__ == "__main__":
    main()
