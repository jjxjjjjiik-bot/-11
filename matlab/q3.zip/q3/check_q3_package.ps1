$ErrorActionPreference = "Stop"

$matlabDir = $PSScriptRoot
$matlabParent = Split-Path -Parent $matlabDir
$root = Split-Path -Parent $matlabParent
$sourceParent = Get-ChildItem -LiteralPath $root -Directory | Where-Object {
    Test-Path -LiteralPath (Join-Path $_.FullName "q3\q3_source_manifest.csv")
} | Select-Object -First 1 -ExpandProperty FullName
$sourceDir = if ($sourceParent) { Join-Path $sourceParent "q3" } else { $null }

if (-not $sourceDir) {
    throw "Cannot locate the q3 source directory from project root: $root"
}

$requiredSourceFiles = @(
    "q3_source_manifest.csv",
    "q3_parameter_table.csv",
    "q3_evidence_notes.md",
    "q3_extraction_notes.csv",
    "q3_scoring_rules.csv"
)

$requiredMatlabFiles = @(
    "run_q3_all.m",
    "load_q3_data.m",
    "build_q3_profiles.m",
    "build_q3_plans.m",
    "q3_apply_safety_constraints.m",
    "q3_topsis_rank.m",
    "q3_rank_with_ties.m",
    "q3_model_checks.m",
    "q3_sensitivity_analysis.m",
    "plot_q3_profiles.m",
    "plot_q3_ranking.m",
    "plot_q3_coverage.m"
)

$requiredOutputs = @(
    "q3_profile_scores.csv",
    "q3_plan_scores.csv",
    "q3_plan_ranking.csv",
    "q3_parameter_table_used.csv",
    "q3_scoring_rules_used.csv",
    "q3_model_checks.csv",
    "q3_weight_sensitivity.csv",
    "q3_weight_sensitivity_summary.csv",
    "q3_run_log.txt",
    "q3_results.mat"
)

$failures = New-Object System.Collections.Generic.List[string]

foreach ($name in $requiredSourceFiles) {
    $path = Join-Path $sourceDir $name
    if (-not (Test-Path -LiteralPath $path)) {
        $failures.Add("缺少资料文件: $path")
    }
}

foreach ($name in $requiredMatlabFiles) {
    $path = Join-Path $matlabDir $name
    if (-not (Test-Path -LiteralPath $path)) {
        $failures.Add("缺少 MATLAB 文件: $path")
    }
}

if (-not (Get-ChildItem -LiteralPath $matlabDir -Filter "README_*.md" -File -ErrorAction SilentlyContinue)) {
    $failures.Add("Missing MATLAB README file in: $matlabDir")
}

$manifestPath = Join-Path $sourceDir "q3_source_manifest.csv"
if (Test-Path -LiteralPath $manifestPath) {
    $manifest = Import-Csv -LiteralPath $manifestPath
    foreach ($row in $manifest) {
        if ($row.local_archive_file -and $row.local_archive_file.Trim().Length -gt 0) {
            $localPath = $row.local_archive_file
            if (-not [System.IO.Path]::IsPathRooted($localPath)) {
                $localPath = Join-Path $sourceDir $localPath
            }
            if (-not (Test-Path -LiteralPath $localPath)) {
                $failures.Add("来源清单指向的本地归档不存在: source_id=$($row.source_id), path=$localPath")
            }
        }
    }
}

$matlabFiles = Get-ChildItem -LiteralPath $matlabDir -Filter "*.m" -File -ErrorAction SilentlyContinue
$forbidden = @("saveas\s*\(", "exportgraphics\s*\(", "print\s*\(", "savefig\s*\(", "imwrite\s*\(")
foreach ($file in $matlabFiles) {
    $text = Get-Content -LiteralPath $file.FullName -Raw
    foreach ($pattern in $forbidden) {
        if ($text -match $pattern) {
            $failures.Add("发现自动导图命令: $($file.FullName) pattern=$pattern")
        }
    }
}

$runPath = Join-Path $matlabDir "run_q3_all.m"
if (Test-Path -LiteralPath $runPath) {
    $runText = Get-Content -LiteralPath $runPath -Raw
    foreach ($outputName in $requiredOutputs) {
        if ($runText -notmatch [regex]::Escape($outputName)) {
            $failures.Add("Missing output contract in run_q3_all.m: $outputName")
        }
    }

    $figureFiles = @(
        (Join-Path $matlabDir "plot_q3_profiles.m"),
        (Join-Path $matlabDir "plot_q3_ranking.m"),
        (Join-Path $matlabDir "plot_q3_coverage.m")
    )
    foreach ($figureFile in $figureFiles) {
        if ((Test-Path -LiteralPath $figureFile) -and
            ((Get-Content -LiteralPath $figureFile -Raw) -notmatch "figure\(")) {
            $failures.Add("Missing figure creation in: $figureFile")
        }
        if ((Test-Path -LiteralPath $figureFile) -and
            ((Get-Content -LiteralPath $figureFile -Raw) -notmatch "title\(")) {
            $failures.Add("Missing chart title in: $figureFile")
        }
    }
}

foreach ($file in $matlabFiles) {
    $firstFunction = Get-Content -LiteralPath $file.FullName | Where-Object {
        $_ -match "^\s*function\s+"
    } | Select-Object -First 1
    if (-not $firstFunction) {
        $failures.Add("Missing leading function definition: $($file.FullName)")
    }
}

if ($failures.Count -gt 0) {
    $failures | ForEach-Object { Write-Host $_ }
    exit 1
}

Write-Host "q3 package static check passed."
