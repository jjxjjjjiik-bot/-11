function plans = build_q3_plans(profiles, paramMap)
% BUILD_Q3_PLANS  构建每类画像的 3 套候选方案。

baselineWeightKg = get_param(paramMap, 'P03');
kcalPerKg = get_param(paramMap, 'P27');
periodDays = round(get_param(paramMap, 'P05') * 30);
targetMinKg = baselineWeightKg * get_param(paramMap, 'P06') / 100;
targetMaxKg = baselineWeightKg * get_param(paramMap, 'P07') / 100;

planTypes = ["饮食优先型"; "运动优先型"; "综合平衡型"];
rows = {};

for i = 1:height(profiles)
    profile = profiles(i, :);
    for j = 1:numel(planTypes)
        planType = planTypes(j);
        spec = plan_spec(profile.profile_name, planType);

        dietLossKg = spec.energy_deficit_kcal_day * periodDays / kcalPerKg;
        exerciseLossKg = spec.aerobic_min_week * 6.0 * 4.345 * get_param(paramMap, 'P05') / kcalPerKg;
        rawLossKg = 0.35 * dietLossKg + 0.45 * exerciseLossKg;
        expectedLossKg = min(max(rawLossKg, targetMinKg * 0.70), targetMaxKg);

        effectScore = min(100, 100 * expectedLossKg / targetMaxKg);
        feasibilityScore = compute_feasibility_score(spec, profile);
        persistenceScore = compute_persistence_score(spec, profile);
        coverageVector = [ ...
            spec.cover_activity, spec.cover_energy, spec.cover_monitoring, ...
            spec.cover_unhealthy_food, spec.cover_fruit_veg];
        failureCoverageScore = mean(coverageVector) * 100;
        rows(end+1, :) = { ...
            sprintf('P%d_%d', profile.profile_id, j), profile.profile_id, ...
            string(profile.profile_name), string(planType), ...
            spec.energy_deficit_kcal_day, spec.aerobic_min_week, ...
            spec.strength_days_week, spec.monitoring_days_week, ...
            spec.sleep_hours_target, spec.sleep_action_score, spec.diet_structure_score, ...
            spec.time_burden_min_day, expectedLossKg, ...
            effectScore, feasibilityScore, persistenceScore, ...
            failureCoverageScore, ...
            spec.cover_activity, spec.cover_energy, spec.cover_monitoring, ...
            spec.cover_unhealthy_food, spec.cover_fruit_veg, ...
            string(spec.plan_summary)};
    end
end

plans = cell2table(rows, 'VariableNames', { ...
    'plan_id','profile_id','profile_name','plan_type', ...
    'energy_deficit_kcal_day','aerobic_min_week','strength_days_week', ...
    'monitoring_days_week','sleep_hours_target','sleep_action_score','diet_structure_score', ...
    'time_burden_min_day','expected_loss_kg_6m', ...
    'effect_score','feasibility_score','persistence_score', ...
    'failure_coverage_score', ...
    'cover_activity','cover_energy','cover_monitoring', ...
    'cover_unhealthy_food','cover_fruit_veg','plan_summary'});
end

function spec = plan_spec(profileName, planType)
spec = struct();
spec.plan_type = planType;
spec.plan_summary = "";
spec.sleep_hours_target = 7;

switch planType
    case "饮食优先型"
        spec.energy_deficit_kcal_day = 750;
        spec.aerobic_min_week = 150;
        spec.strength_days_week = 2;
        spec.monitoring_days_week = 5;
        spec.sleep_action_score = 65;
        spec.diet_structure_score = 92;
        spec.cover_activity = 0.5;
        spec.cover_energy = 1.0;
        spec.cover_monitoring = 0.5;
        spec.cover_unhealthy_food = 1.0;
        spec.cover_fruit_veg = 1.0;
        spec.time_burden_min_day = 46;
        spec.plan_summary = "控能量、控油糖快餐、提高蔬菜全谷物，运动保持指南下限。";
    case "运动优先型"
        spec.energy_deficit_kcal_day = 550;
        spec.aerobic_min_week = 300;
        spec.strength_days_week = 3;
        spec.monitoring_days_week = 4;
        spec.sleep_action_score = 60;
        spec.diet_structure_score = 70;
        spec.cover_activity = 1.0;
        spec.cover_energy = 0.5;
        spec.cover_monitoring = 0.5;
        spec.cover_unhealthy_food = 0.5;
        spec.cover_fruit_veg = 0.5;
        spec.time_burden_min_day = 66;
        spec.plan_summary = "提高有氧和抗阻训练，饮食控制保持保守能量缺口。";
    otherwise
        spec.energy_deficit_kcal_day = 650;
        spec.aerobic_min_week = 210;
        spec.strength_days_week = 2;
        spec.monitoring_days_week = 6;
        spec.sleep_action_score = 78;
        spec.diet_structure_score = 84;
        spec.cover_activity = 1.0;
        spec.cover_energy = 1.0;
        spec.cover_monitoring = 1.0;
        spec.cover_unhealthy_food = 1.0;
        spec.cover_fruit_veg = 1.0;
        spec.time_burden_min_day = 55;
        spec.plan_summary = "饮食、运动、监测和睡眠同步推进，追求稳态执行。";
end

if profileName == "久坐办公型"
    spec.time_burden_min_day = spec.time_burden_min_day + 2;
    spec.plan_summary = spec.plan_summary + "；每坐 60 分钟起身活动 3-5 分钟，每周安排 5 次午间步行和 2 次下班有氧。";
elseif profileName == "夜班熬夜型"
    spec.sleep_action_score = min(100, spec.sleep_action_score + 15);
    spec.feasibility_penalty = 9;
    spec.time_burden_min_day = spec.time_burden_min_day + 4;
    spec.cover_monitoring = 1.0;
    spec.plan_summary = spec.plan_summary + "；夜班日采用 3+1 餐次，按班次固定不少于 7 小时睡眠窗口，备低能量加餐并记录夜间进食。";
elseif profileName == "高压应酬型"
    spec.feasibility_penalty = 7;
    spec.cover_monitoring = 1.0;
    spec.plan_summary = spec.plan_summary + "；应酬前定量加餐，酒桌优先蔬菜和优质蛋白；应酬次日不极端节食，补做 30 分钟快走并记录饮酒外食。";
elseif profileName == "时间受限型"
    spec.monitoring_days_week = min(7, spec.monitoring_days_week + 1);
    spec.time_burden_min_day = spec.time_burden_min_day - 8;
    spec.feasibility_bonus = 4;
    spec.cover_monitoring = 1.0;
    spec.plan_summary = spec.plan_summary + "；每日安排 3 次 10-15 分钟碎片化运动，周末集中备餐，手机记录体重和饮食。";
elseif profileName == "饮食失衡型"
    spec.diet_structure_score = min(100, spec.diet_structure_score + 8);
    spec.plan_summary = spec.plan_summary + "；替换甜食油炸快餐，保证每日蔬菜 300-500g 和全谷杂豆。";
end

if ~isfield(spec, 'feasibility_penalty')
    spec.feasibility_penalty = 0;
end
if ~isfield(spec, 'feasibility_bonus')
    spec.feasibility_bonus = 0;
end
end

function score = compute_feasibility_score(spec, profile)
timeRisk = profile.time_constraint / 100;
sleepRisk = profile.sleep_risk / 100;
stressRisk = profile.stress_risk / 100;

burdenPenalty = max(0, spec.time_burden_min_day - 45) * (0.35 + 0.45 * timeRisk);
sleepFit = spec.sleep_action_score * sleepRisk * 0.08;
monitoringFit = spec.monitoring_days_week * 1.2;
    fitScore = profile_plan_fit(spec.plan_type, profile);
    singleFocusPenalty = single_focus_penalty(spec.plan_type, profile);
    score = 78 - burdenPenalty - 7 * stressRisk + sleepFit + monitoringFit + fitScore - singleFocusPenalty;
    score = score - spec.feasibility_penalty + spec.feasibility_bonus;
    score = max(0, min(100, score));
end

function score = compute_persistence_score(spec, profile)
monitoring = spec.monitoring_days_week / 7 * 100;
burden = spec.time_burden_min_day;
stressRisk = profile.stress_risk / 100;
    singleFocusPenalty = single_focus_penalty(spec.plan_type, profile);
    score = 48 + 0.20 * monitoring + 0.18 * spec.sleep_action_score + ...
    0.12 * spec.diet_structure_score - max(0, burden - 50) * 0.35 - ...
    8 * stressRisk - 0.60 * singleFocusPenalty;
score = max(0, min(100, score));
end

function score = profile_plan_fit(planType, profile)
if planType == "饮食优先型"
    score = 0.16 * profile.diet_risk + 0.04 * profile.stress_risk - 6;
elseif planType == "运动优先型"
    score = 0.18 * profile.sedentary_risk - 0.12 * profile.time_constraint - 2;
else
    score = 0.09 * profile.sleep_risk + 0.08 * profile.stress_risk + ...
        0.06 * profile.monitoring_gap - 3;
end
score = max(-8, min(14, score));
end

function penalty = single_focus_penalty(planType, profile)
if planType == "饮食优先型"
    penalty = 0.12 * profile.sleep_risk + 0.10 * profile.stress_risk - ...
        0.10 * profile.diet_risk;
elseif planType == "运动优先型"
    penalty = 0.08 * profile.diet_risk + 0.05 * profile.sleep_risk;
else
    penalty = 0;
end
penalty = max(0, penalty);
end

function value = get_param(paramMap, parameterId)
if ~isKey(paramMap, parameterId)
    error('缺少参数：%s。请检查 q3_parameter_table.csv。', parameterId);
end
value = paramMap(parameterId);
end
