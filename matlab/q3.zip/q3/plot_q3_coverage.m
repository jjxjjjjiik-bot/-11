function plot_q3_coverage(ranking)
% PLOT_Q3_COVERAGE  生成干预措施覆盖热图窗口。

fontName = q3_choose_font();
coverageCols = {'cover_activity','cover_energy','cover_monitoring', ...
    'cover_unhealthy_food','cover_fruit_veg'};
coverageLabels = {'活动增加', '能量控制', '体重监测', '少甜炸快餐', '增加果蔬'};

bestRows = false(height(ranking), 1);
profileIds = unique(ranking.profile_id, 'stable');
for i = 1:numel(profileIds)
    idx = find(ranking.profile_id == profileIds(i));
    [~, localBest] = max(ranking.topsis_score(idx));
    bestRows(idx(localBest)) = true;
end
best = ranking(bestRows, :);
matrix = best{:, coverageCols};

fig = figure('Name', '问题三-干预措施覆盖热图', ...
    'NumberTitle', 'off', 'Color', 'w', 'Position', [140 110 1120 720]);
ax = axes('Parent', fig);
imagesc(ax, matrix);
colormap(ax, parula(256));
cb = colorbar(ax);
cb.Label.String = '覆盖度';
cb.Label.FontName = fontName;
cb.Label.FontSize = 13;
cb.FontName = fontName;
cb.FontSize = 12;
caxis(ax, [0 1]);

ax.FontName = fontName;
ax.FontSize = 13;
ax.XTick = 1:numel(coverageLabels);
ax.XTickLabel = coverageLabels;
ax.XTickLabelRotation = 18;
ax.YTick = 1:height(best);
ax.YTickLabel = best.profile_name;
ax.TickLength = [0 0];
axis(ax, 'tight');
title(ax, '问题三-干预措施覆盖热图', 'FontName', fontName, ...
    'FontSize', 18, 'FontWeight', 'bold');

for row = 1:size(matrix, 1)
    for col = 1:size(matrix, 2)
        if matrix(row, col) > 0.72
            txtColor = 'w';
        else
            txtColor = [0.1 0.1 0.1];
        end
        text(ax, col, row, sprintf('%.2f', matrix(row, col)), ...
            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
            'FontName', fontName, 'FontSize', 12, 'FontWeight', 'bold', ...
            'Color', txtColor);
    end
end

xlabel(ax, '对问题二失败因素的修正覆盖维度', 'FontName', fontName, 'FontSize', 14);
ylabel(ax, '典型生活方式画像', 'FontName', fontName, 'FontSize', 14);
set(ax, 'LooseInset', max(get(ax, 'TightInset'), [0.06 0.06 0.04 0.04]));
end

function fontName = q3_choose_font()
preferred = {'Microsoft YaHei', 'SimHei', 'SimSun'};
available = listfonts;
fontName = get(groot, 'defaultAxesFontName');
for i = 1:numel(preferred)
    if any(strcmpi(available, preferred{i}))
        fontName = preferred{i};
        return;
    end
end
end
